const shortid = require('shortid');
const AssetHelper = require('../game/AssetHelper');
const QuestHelper = require('../game/QuestHelper');
const Building = require('../game/entity/Building');
const Task = require('../game/entity/Task');

module.exports = {
    Produce (room, client, data) {
        var state = room.state;
        var playerId = room.sessionMap[client.sessionId];
        var player = state.players[playerId];
        var [ action, building_ids, product, slot ] = data;
        var curTasks = state.tasks;
        var taskDefine = AssetHelper.GetTaskByAction(action, building_ids, product);
        var singleBP = AssetHelper.IsSinglePB(building_ids);
        var id, task;

        console.log(singleBP);

        if (!taskDefine) {
            room.send(client, {
                type: 'error',
                message: 'Cannot find task defination.',
                action: data
            });
            return;
        }

        // check if task slot is already occupied
        // task = curTasks.find(t => (t.building == building_ids && t.slot == slot));
        // if (task != null) {
        //     room.send(client, {
        //         type: 'error',
        //         message: 'Task is already occupied.',
        //         action: data
        //     });
        //     return;
        // }

        for(id in curTasks) {
            task = curTasks[id];
            if (task.building == building_ids) {
                if (task.slot == slot) {
                    room.send(client, {
                        type: 'error',
                        message: 'Task is already occupied.',
                        action: data
                    });
                    return;
                }
                if (singleBP && task.player == playerId) {
                    console.log(task);
                    room.send(client, {
                        type: 'error',
                        message: 'Player cannot produce more than 1 slot.',
                        action: data
                    });
                    return;
                }
            }
        }

        var input = taskDefine.input;
        var canExecute = true;
        var additionalInfo = "";
        for (var id_s in input) {
            if (!state.inventory[id_s] || state.inventory[id_s] < input[id_s]) {
                additionalInfo = id_s;
                canExecute = false;
            }
        }

        if (taskDefine.energy_to_collect && !player.HasEnergy(taskDefine.energy_to_collect)) {
            additionalInfo = "(Energy)";
            canExecute = false;
        }
        

        if (!canExecute) {
            room.send(client, {
                type: 'error',
                message: 'Not enough resouce: ' + additionalInfo,
                action: data
            });
            return;
        }

        console.log('can execute task ' + taskDefine.id_string);
        if (canExecute === true) {
            for (var id_s in input) {
                state.inventory[id_s] -= input[id_s];
            }

            if (taskDefine.energy_to_collect)
                player.UseEnergy(taskDefine.energy_to_collect);

            task = new Task(taskDefine.id_string, playerId, action, building_ids, slot, taskDefine.duration);
            
            // state.tasks.push(task);
            state.tasks[shortid.generate()] = task;
        }
    },

    Collect (room, client, data) {
        var state = room.state;
        var [ action, building_ids, slot ] = data;
        var curTasks = state.tasks;
        var id, task, tmp;

        // Check if task still available
        // var taskIndex = curTasks.findIndex(t => (t.building == building_ids && t.slot == slot));
        // if (taskIndex == -1) {
        //     room.send(client, {
        //         type: 'error',
        //         message: 'Canot find task or task is fulfilled by other player.',
        //         action: data
        //     });
        //     return;
        // }

        for(id in curTasks) {
            task = curTasks[id];
            if (task.building == building_ids && task.slot == slot) {
                tmp = id;
                break;
            }
        }
        
        if (!tmp) {
            room.send(client, {
                type: 'error',
                message: 'Canot find task or task is fulfilled by other player.',
                action: data
            });
            return;
        }

        // task = curTasks[taskIndex];
        task = curTasks[tmp];
        if (!task.IsCompleted()) {
            console.log('task ' + task.id + ' isn\'t completed.');
            room.send(client, {
                type: 'error',
                message: 'Task isn\'t completed yet.',
                action: data
            });
            return;
        }

        var taskDefine = AssetHelper.GetTaskByString(task.id);
        if (!taskDefine) {
            room.send(client, {
                type: 'error',
                message: 'Cannot find task defination.',
                action: data
            });
            return;
        }

        console.log('can collect ' + task.id);
        var product = taskDefine.product;
        var amount = taskDefine.amount;
        state.inventory[product] = (state.inventory[product] || 0) + amount;

        // curTasks.splice(taskIndex, 1);
        delete curTasks[id];

        // Check if quest is completed
        console.log(state.quest);
        if (!!state.quest && state.quest != '-1') {
            var questId = state.quest;
            console.log('Check quest status' + questId);
            try {
                if (QuestHelper.IsCompleted(questId, state)) {
                    console.log('Complete quest ' + questId);

                    var rewards = QuestHelper.TurnInQuest(questId, state);

                    room.send(client, {
                        type: 'quest',
                        message: 'Quest completed.',
                        code: 'quest_complete',
                        rewards: rewards,
                        next: state.quest
                    });
                }
            } catch (e) {
                room.send(client, {
                    type: 'error',
                    message: e.message,
                    action: data
                });
            }
        }
    },

    UnlockBuilding (room, client, data) {
        var state = roo.state;
        var [ action, building_ids ] = data;
        var curTasks = state.tasks;
        var taskDefine = AssetHelper.GetTaskByAction(action, building_ids);

        
    },

    UpgradeBuilding (room, client, data) {

    },

    SpeedUpTask (room, client, data) {
        var state = roo.state;
        var [ command, action, building_ids ] = data;
        var curTasks = state.tasks;

        var taskDefine, taskIndex;
        if (action == 'produce') {
            taskDefine = AssetHelper.GetTaskByAction(action, building_ids, product);
            taskIndex = curTasks.findIndex(t => (t.action == action && t.building == building_ids && t.slot == slot));
        } else if (action == "unlock") {
            taskDefine = AssetHelper.GetTaskByAction(action, building_ids);
            taskIndex = curTasks.findIndex(t => (t.action == action && t.building == building_ids));
        } else if (action == "upgrade") {
            if (state.buildings[building]) {
                taskDefine = AssetHelper.GetTaskByAction(action, building_ids, null, state.buildings[building_ids].level);
                taskIndex = curTasks.findIndex(t => (t.action == action && t.building == building_ids));
            }
        }

        if (!taskDefine){
            return;
        }

        if (!taskIndex){
            return;
        }

        var task = curTasks[taskIndex];
        if (task.IsCompleted()) {
            console.log('Task ' + task.id + ' is completed.');
            return;
        }

        // DO speed up
        task.SpeedUp(taskDefine.speedup_amount);

        // Check task complete
        if (task.IsCompleted()) {
            console.log('Task ' + task.id + ' is completed after speed up.');

            if (action == 'produce') {
                var product = taskDefine.product;
                var amount = taskDefine.amount;
                state.inventory[product] = (state.inventory[product] || 0) + amount;
            } else if (action == 'unlock') {
                state.buildings[building_ids] = new Building[building_ids]();
            }

            curTasks.splice(taskIndex, 1);
        }
    }
}
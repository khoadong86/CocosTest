module.exports = {
    EnergyUpdate (room, client, data) {
        var state = room.state;
        var playerId = room.sessionMap[client.sessionId];
        var player = state.players[playerId];

        player.UpdateEngergy();

        room.send(client, {
            type: 'energy',
            energy: player.energy,
            energyTick: player.energyTick
        });
    },
}
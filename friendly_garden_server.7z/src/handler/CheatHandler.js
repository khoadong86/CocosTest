const AssetHelper = require('../game/AssetHelper');

module.exports = {
    CheatEnergy (room, client, data) {
        var state = room.state;
        var playerId = room.sessionMap[client.sessionId];
        var player = state.players[playerId];

        player.RefillEnergy(1);
    },

    CheatResetFarm (room, client, data) {
        var state = room.state;
        var players = state.players;


        console.log('cheat reset farm');
        state.New();
        state.players = players;
    },

    CheatInventory (room, client, data) {
        var state = room.state;
        var playerId = room.sessionMap[client.sessionId];
        var player = state.players[playerId];

        var [ action, item, amount ] = data;

        var itemDefine = AssetHelper.GetItemByString(item);

        if (!itemDefine) {
            room.send(client, {
                type: 'error',
                message: `Item ${item} isn't defined.`,
                action: data
            });
            return;
        }

        state.inventory[item] += amount;

        if (state.inventory[item] < 0)
            state.inventory[item] = 0;
    }
}
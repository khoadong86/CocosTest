var global = {};

export default global;
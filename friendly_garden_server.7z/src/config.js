var DEBUG = !!process.env.DEBUG;

var MONGO_URL = "ds018558.mlab.com:18558/friendly_garden";
if (DEBUG) {
    MONGO_URL = "localhost:27017/friendly_garden";
}

module.exports = {
    DEBUG: DEBUG,
    APP_SECRET: "",
    MONGO_URL: MONGO_URL,
    MONGO_USERNAME: "trieu.nguyenlam",
    MONGO_PASSWORD: "gameloftdev2018",
    MONGO_DATABASE: "friendly_garden"
};
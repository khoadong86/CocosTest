const crypto = require('crypto-js');
const config = require('../config');

module.exports = {
    Validate (data) {
        try{
            var parts = data.split('.');
            var firstpart = parts[0];
            var replaced = firstpart.replace(/-/g, '+').replace(/_/g, '/');
            var signature = crypto.enc.Base64.parse(replaced).toString();
            var dataHash = crypto.HmacSHA256(parts[1], config.APP_SECRET).toString();
            var isValid = signature === dataHash;
            if (!isValid) {
                console.log('Invalid signature');
                console.log('firstpart', firstpart);
                console.log('replaced ', replaced);
                console.log('Expected', dataHash);
                console.log('Actual', signature);
            }
            
            return isValid;
        } catch (e) {
            return false;
        }
    },
    
    GetData(data) {
        try {
            var json = crypto.enc.Base64.parse(data.split('.')[1]).toString(crypto.enc.Utf8);
            var encodedData = JSON.parse(json);
            
            /*
            Here's an example of encodedData can look like
            { 
                algorithm: 'HMAC-SHA256',
                issued_at: 1520009634,
                player_id: '123456789',
                request_payload: 'backend_save' 
            } 
            */
            
            return encodedData.request_payload;
        } catch (e) {
            return null;
        }
    },
    
    ValidateAndGetData (data) {
        try{
            var parts = data.split('.');
            var firstpart = parts[0];
            var replaced = firstpart.replace(/-/g, '+').replace(/_/g, '/');
            var signature = crypto.enc.Base64.parse(replaced).toString();
            var dataHash = crypto.HmacSHA256(parts[1], config.APP_SECRET).toString();
            var isValid = signature === dataHash;
            if (!isValid) {
                console.log('Invalid signature');
                console.log('firstpart', firstpart);
                console.log('replaced ', replaced);
                console.log('Expected', dataHash);
                console.log('Actual', signature);
            }
            
            if (isValid) {
                var json = crypto.enc.Base64.parse(parts[1]).toString(crypto.enc.Utf8);
                var encodedData = JSON.parse(json);
                return encodedData.request_payload;
            } else {
                return null;
            }
        } catch (e) {
            return null;
        }
    }
};
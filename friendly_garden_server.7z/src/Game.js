const colyseus = require('colyseus');
const __awaiter = require('./utils/awaiter');
const GameDBHelper = require('./GameDBHelper');

const State = require('./State');
const Player = require('./game/entity/Player');

const FarmHandler = require('./handler/FarmHandler');
const PlayerHandler = require('./handler/PlayerHandler');
const CheatHandler = require('./handler/CheatHandler');

class Game extends colyseus.Room {

    constructor () {
        super();

        this.maxClients = 25;
    
        this.roomContext = null;
    
        this.sessionMap = {};
    }

    onInit (options) {
        console.log('Create new Room ' + options.roomContext);
        this.roomContext = options.roomContext;
        this.setState(new State());

        GameDBHelper.GetFarmData(this.roomContext)
            .then((doc) => {
                if (doc) {
                    console.log('Load farm state');
                    GameDBHelper.LoadFarmState(this.state, doc);
                } else {
                    console.log('Create new farm state');
                    this.state.New();
                    GameDBHelper.SaveFarmState(this.roomContext, this.state, true);
                }
            })
            .catch((err) => {
                console.log('error when load or create new farm');
                console.log(err);
            })
    }

    // requestJoin (options, isNew) {
    //     return true;
    // }

    onAuth (options) {
        return true;
    }

    onJoin (client, options, auth) {
        var playerId = options.playerId;
        var sessionId = client.sessionId;
        var player = this.state.players[playerId];

        if ( player ) {
            // Player already in room
            console.log('Same player joined room: ' + playerId);
        } else {
            // New player join room
            // Notify others
            console.log('New player joined room: ' + playerId);
            player = this.state.registeredPlayers[playerId];
            if (!player) {
                console.log(`Player ${playerId} join room for the 1st time`);
                player = new Player();
                this.state.registeredPlayers[playerId] = player;
            }
            this.state.players[playerId] = player;
        }

        this.sessionMap[sessionId] = options.playerId;
        player.refCount++;

        player.UpdateEngergy();
        this.send(client, {
            type: 'energy',
            energy: player.energy,
            energyTick: player.energyTick
        });
    }

    onLeave (client) {
        var sessionId = client.sessionId;
        var playerId = this.sessionMap[sessionId];
        var player = this.state.players[playerId];

        console.log('Player leave room: ' + playerId);
        this.allowReconnection(client, 5)
            .then((client) => {
                console.log('Player reconnect room: ' + playerId);
            })
            .catch(() => {
                if (this.sessionMap.hasOwnProperty(sessionId)) {
                    delete this.sessionMap[sessionId];
                }

                player.refCount--;
                if (player.refCount === 0) {
                    // Notify player has left
                    console.log('Player has been dismissed: ' + playerId);
                    delete this.state.players[playerId];
                }
            });
    }

    onMessage (client, data) {
        var playerId = this.sessionMap[client.sessionId];
        var player = this.state.players[playerId];

        console.log(data);
        if (data[0] === 'produce') {
            FarmHandler.Produce(this, client, data);
        }
        else if (data[0] === 'collect') {
            FarmHandler.Collect(this, client, data);
        }
        else if (data[0] == 'energy_update') {
            PlayerHandler.EnergyUpdate(this, client, data);
        }
        else if (data[0] == 'cheat_energy') {
            CheatHandler.CheatEnergy(this, client, data);
        }
        else if (data[0] == 'cheat_inventory') {
            CheatHandler.CheatInventory(this, client, data);
        }
        else if (data[0] == 'cheat_reset_farm') {
            CheatHandler.CheatResetFarm(this, client, data);
        }
    }

    onDispose () {
        return new Promise((resolve, reject) => {
            console.log('Close Room ' + this.roomContext);
            return GameDBHelper.SaveFarmState(this.roomContext, this.state)
                .then((saved) => {
                    console.log('Saved successfuly.');
                })
        })
    }

    update (dt) {
    }

    getAvailableData () {
        return __awaiter(this, void 0, void 0, function* () {
            return {
                clients: this.clients.length,
                maxClients: this.maxClients,
                metadata: this.metadata,
                roomId: this.roomId,
                roomContext: this.roomContext
            };
        });
    }

    getRoomContext () {
        return __awaiter(this, void 0, void 0, function* () {
            return {
                roomId: this.roomId,
                roomContext: this.roomContext
            }
        });
    }
}

module.exports = Game;
module.exports = function (object, key) {
    if (typeof object === 'object' && object.hasOwnProperty(key)) {
        var descriptor = Object.getOwnPropertyDescriptor(object, key);
        if (descriptor.enumerable === false)
            return;

        if (descriptor.configurable) {
            Object.defineProperty(object, 'property1', {
                enumerable: false
            });
        } else {
            delete object[key];
            descriptor.enumerable = false;
            Object.defineProperty(object, key, descriptor);
        }
    }
}
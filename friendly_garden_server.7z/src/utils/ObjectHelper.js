 var ObjectHelper = {
    unenumerable (object, key) {
        if (typeof object === 'object' && object.hasOwnProperty(key)) {
            var descriptor = Object.getOwnPropertyDescriptor(object, key);
            if (descriptor.enumerable === false)
                return;
    
            if (descriptor.configurable) {
                Object.defineProperty(object, key, {
                    enumerable: false
                });
            } else {
                delete object[key];
                descriptor.enumerable = false;
                Object.defineProperty(object, key, descriptor);
            }
        }
    },

    clone (source) {
        var clone;
        if (source instanceof Array) {
            clone = source.slice();
        }
        else if (source instanceof Object) {
            clone = {};
            for (var key in source) {
                clone[key] = ObjectHelper.clone(source[key]);
            }
        } else {
            clone = source;
        }
        return clone;
    }
}

module.exports = ObjectHelper;
const shortid = require('shortid');
const { MongoClient, Db, Collection } = require('mongodb');
const Player = require('./game/entity/Player');
const Building = require('./game/entity/Building');
const Task = require('./game/entity/Task');
const AssetHelper = require('./game/AssetHelper');
const config = require('./config');

const BATCH_COUNT = 100;
const INTERVAL = 20000;

const FARM = 'Farm';
const COLLECTIONS = [
    FARM
];

class GameDBHelper {

    constructor () {
        this.db = null;
        this.collection = {};
        this.operations = {};
        this.updateInterval= null;
    }

    Connect () {
        return new Promise((resolve, reject) => {
            var uri = `mongodb://${config.MONGO_USERNAME}:${config.MONGO_PASSWORD}@${config.MONGO_URL}`;
            if (config.DEBUG) {
                uri = `mongodb://${config.MONGO_URL}`;
            }
            console.log(uri);
            MongoClient.connect(uri, {
                useNewUrlParser: true
            })
            .then((client) => {
                this.db = client.db(config.MONGO_DATABASE);
                for (var cName of COLLECTIONS) {
                    this.collection[cName] = this.db.collection(cName);
                    this.operations[cName] = [];
                }
                this.updateInterval = setInterval(this.BulkExecute.bind(this), INTERVAL);

                resolve();
            })
            .catch((err) => {
                console.error(err);
                reject("Cannot connect to database.");
            })
        });
    }

    BulkPush (collectionName, operation)
    {
        var operations = this.operations[collectionName];
        
        operations.push(operation);

        if (operations.length >= BATCH_COUNT)
        {
            this.BulkExecute();
        }
    }

    BulkExecute ()
    {
        for (var cName in this.collection) {
            var collection = this.collection[cName];
            var operations = this.operations[cName];

            if (operations.length == 0)
                return;

            console.log(`GameDBHelper: BulkWrite to "${cName}" - ${operations.length} operations.`);

            collection.bulkWrite(
                operations,
                {ordered: false}
            )
            .catch((err) =>
                {
                    if (err != null)
                    {
                        console.log("GameDBHelper: BulkWrite has countered some errors");
                        console.error(err);
                    }
                });
    
            this.operations = [];
        }
    }

    /**
     * Get the first farm that match the context
     * @param {*} roomContextId 
     * @return {Promise}
     */
    GetFarmData (roomContextId) {
        var farm = this.collection[FARM];
        return farm.findOne({
            context: roomContextId
        })
    }

    CreateFarmData (roomContextId, state) {

    }

    LoadFarmState (state, doc) {
        var id, id_string, temp;

        for (id in doc.players) {
            var player = doc.players[id];
            state.registeredPlayers[id] = new Player(player.energy, player.energyTick);
        }

        if (doc.buildings) {
            var buildings = doc.buildings;
            for(id in buildings) {
                try {
                    if (isNaN(id))
                        state.buildings[id] = new Building[id](temp);
                    else {
                        id_string = AssetHelper.GetAsset(id);
                        state.buildings[id] = new Building[id_string](temp);
                    }
                } catch (e) {
                    console.error(e);
                }
            }
        }
        
        if (doc.inventory) {
            var inventory = doc.inventory;
            for(id in inventory) {
                temp =  inventory[id];
                state.inventory[id] = temp;
            }
        }
        
        // if (doc.tasks) {
        //     var tasks = doc.tasks;
        //     for(temp of tasks) {
        //         state.tasks.push(new Task(temp.id, temp.player, temp.action, temp.building, temp.slot, temp.duration, temp.start_date));
        //     }
        // }
        
        if (doc.tasks) {
            var tasks = doc.tasks;
            for(temp of tasks) {
                id = shortid.generate();
                state.tasks[id] = new Task(temp.id, temp.player, temp.action, temp.building, temp.slot, temp.duration, temp.start_date);
            }
        }

        if (doc.quest) {
            state.quest = doc.quest;
        }

        console.log(state.tasks)
    }

    SaveFarmState (roomContext, state, isNew=false) {
        console.log('Save Farm for context ' + roomContext);
        var id, tmp;

        var updateObject = {
            players: {},
            buildings: {},
            inventory: {},
            tasks: []
        };

        for (id in state.registeredPlayers) {
            updateObject.players[id] = state.registeredPlayers[id].Export();
        }

        for (id in state.buildings) {
            if (isNaN(id))
                updateObject.buildings[id] = state.buildings[id].Export();
            else {
                id_string = AssetHelper.GetAsset(id);
                updateObject.buildings[id_string] =  state.buildings[id_string].Export();
            }
        }

        for (id in state.inventory) {
            updateObject.inventory[id] = state.inventory[id];
        }

        // for (tmp of state.tasks) {
        //     updateObject.tasks.push(tmp.Export());
        // }

        for (id in state.tasks) {
            updateObject.tasks.push(state.tasks[id].Export());
        }

        if (state.quest) {
            updateObject.quest = state.quest;
        }

        console.log(updateObject);

        // Push to database
        if (isNew) {
            updateObject.context = roomContext;

            return this.collection[FARM].insertOne(
                updateObject
            );
        } else {
            return this.collection[FARM].updateOne(
                { context: roomContext },
                { $set: updateObject }
            );
        }
    }
}

module.exports = new GameDBHelper();
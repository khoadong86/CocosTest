const { unenumerable, clone } = require('./utils/ObjectHelper');
const Player = require('./game/entity/Player');
const Building = require('./game/entity/Building');
const AssetHelper = require('./game/AssetHelper');

class State {
    constructor () {
        this.players = {};
        this.buildings = {};
        this.inventory = {};
        this.tasks = {};
        this.quest = INIT_DATA.quest;

        this.registeredPlayers = {};

        unenumerable(this, 'registeredPlayers');
    }

    New () {
        this.players = {};

        for (var id in INIT_DATA.buildings) {
            
            if (isNaN(id))
                this.buildings[id] = new Building[id](INIT_DATA.buildings[id]);
            else {
                id_string = AssetHelper.GetAsset(id);
                this.buildings[id] = new Building[id_string](INIT_DATA.buildings[id_string]);
            }
        }

        for (var id in INIT_DATA.inventory) {
            this.inventory[id] = clone(INIT_DATA.inventory[id]);
        }

        this.tasks = {};

        this.quest = INIT_DATA.quest;
    }

    static GetInitData () {
        return INIT_DATA;
    }
}

const INIT_DATA = {
    buildings: {
        'Farm_HQ': {
            level: 1
        },
        'Farm_Storage_Barn': {
            level: 1
        },
        'PB_Mill': {
            level: 1
        },
        // 'PB_Bread_Oven': {
        //     level: 1
        // },
        'PB_Soil_Plot': {
            size: 3
        }
    },
    inventory: {
        'coin': 200,
        'Ing_Wheat_Crop': 2
    },
    quest: '9000'
}

module.exports = State;
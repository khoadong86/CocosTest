module.exports =
{
  "9000": {
    "Quest_ID": 9000,
    "Quest": "Collect 3 wheat",
    "Counters": "Ing_Wheat_Crop",
    "Quantity": 3,
    "Requirement_ID": 11001,
    "Requirements": "Welcome to Friendly Garden! Plant and harvest wheat on the fealds. Collect 9 wheat in total.",
    "Reward_1": "400,soft_currency",
    "Quest Hint Icon": "Hand pointing at field ",
    "Next_Quest": 9001
  },
  "9001": {
    "Quest_ID": 9001,
    "Quest": "Collect 9 wheat",
    "Counters": "Ing_Wheat_Crop",
    "Quantity": 9,
    "Reward_1": "900,soft_currency",
    "Next_Quest": 9003
  },
  "9003": {
    "Quest_ID": 9003,
    "Quest": "Bake 4 bread",
    "Counters": "Ing_Bread",
    "Quantity": 4,
    "Requirement_ID": 11002,
    "Requirements": "Well done! Use hard-eanred coins to unlcok Bakery and bake 4 bread.",
    "Reward_1": "1000,soft_currency",
    "Quest Hint Icon": "Hand pointing at bakery sign ",
    "Next_Quest": 9005
  },
  "9005": {
    "Quest_ID": 9005,
    "Quest": "Bake 2 bread and make 2 flour",
    "Counters": "Ing_Bread,Ing_Bread,Ing_Flour",
    "Quantity": "2,2",
    "Requirement_ID": 11003,
    "Requirements": "Excellent! Now purchase the Mill and grind 2 items of flour. Also, bake 2 bread in the Bakery.",
    "Reward_1": "300,soft_currency ",
    "Reward_2": "4,Ing_Sugar_Cane_Crop",
    "Reward_3": "4,Ing_Wheat_Crop",
    "Quest Hint Icon": "Hands pointing at mill sign and bakery"
  },
  "9006": {
    "Quest_ID": 9006,
    "Quest": "Collect 6 sugar cane",
    "Quantity": 6,
    "Requirement_ID": 11004,
    "Requirements": "Now you know the basics. Continue playing to unlock muffins! The first step is to plant sugar cane and collect 6 items of it. ",
    "Reward_1": "200,soft_currency",
    "Quest Hint Icon": "Hand pointing at field "
  },
  "9007": {
    "Quest_ID": 9007,
    "Quest": "Make 2 bags of sugar",
    "Quantity": 2,
    "Requirement_ID": 11005,
    "Requirements": "Make 2 sugar at the Mill.",
    "Reward_1": "300,soft_currency",
    "Reward_2": "3,Ing_Sugar_Cane_Crop",
    "Reward_3": "1,fill_energy",
    "Quest Hint Icon": "Hand pointing at the mill"
  },
  "9008": {
    "Quest_ID": 9008,
    "Quest": "Make 6 muffins",
    "Quantity": 6,
    "Requirement_ID": 11006,
    "Requirements": "Use what you have learned to make 6 muffins at the Bakery.",
    "Reward_1": "Finish the proto message",
    "Quest Hint Icon": "Hand pointing at the bakery"
  },
  "9009": {
    "Quest_ID": 9009,
    "Quest": "Prototype complete",
    "Quantity": 1,
    "Requirement_ID": 11007,
    "Requirements": "Congratulations! You have finished the prototype. You can continue playing.",
    "Reward_1": "Endless mode"
  }
};
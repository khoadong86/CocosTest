const AssetHelper = require('./AssetHelper');

module.exports = {
    IsCompleted (questId, state) {
        var questDefine = AssetHelper.GetQuestById(questId);
        
        if (!questDefine) {
            throw Error('Cannot find definition of quest ' + questId);
        }

        var counters = questDefine['Counters'].split(',');
        var quantities = String(questDefine['Quantity']).split(',');

        var isComplete = true;
        var requirement = {};
        counters.forEach(function(item, index) {
            if (!state.inventory[item] 
                || state.inventory[item] < quantities[index]
            ) {
                isComplete = false;
            }
        });

        return isComplete;
    },

    TurnInQuest (questId, state) {
        var questDefine = AssetHelper.GetQuestById(questId);
        var rewards = {};
        var inventory = state.inventory;

        if (!questDefine) {
            throw Error('Cannot find definition of quest ' + questId);
        }

        ['Reward_1','Reward_2','Reward_3'].forEach(function (slot) {
            if (!!questDefine[slot]) {
                var data = questDefine[slot].split(',');

                if (data[1] == 'soft_currency')
                    data[1] = 'coin';

                if (!isNaN(data[0]) && AssetHelper.GetItemByString(data[1])) {
                    var amount = parseInt(data[0]);
                    rewards[data[1]] = amount;
                    if (!isNaN(amount)) {
                        inventory[data[1]] = (inventory[data[1]] || 0) + amount;
                    }
                }
            }
        })

        if (!!questDefine['Next_Quest']) {
            state.quest = String(questDefine['Next_Quest']);
        } else {
            state.quest = '-1';
        }

        return rewards;
    }
}
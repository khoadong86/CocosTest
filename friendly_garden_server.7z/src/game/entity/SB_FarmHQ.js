const { unenumerable } = require('../../utils/ObjectHelper');

class FarmHQ {
    constructor (data={}) {
        this.level = data.level || 1;
    }

    Export () {
        return {
            level: this.level
        }
    }
}

module.exports = FarmHQ;
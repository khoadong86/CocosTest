const { unenumerable } = require('../../utils/ObjectHelper');

const MAX_ENERGY = 10;
const ENERY_RECOVERY_TIME = 30*60*1000; // 1 energy per 30 mins

class Player {
    
    constructor (energy=MAX_ENERGY, energyTick=null) {
        this.refCount = 0;
        this.energy = energy;
        this.energyTick = energyTick || Date.now();

        unenumerable(this, 'refCount');
        unenumerable(this, 'energyTick');
    }

    RefillEnergy (amount) {
        this.energy += amount;
        if (this.energy > MAX_ENERGY) {
            this.energy = MAX_ENERGY;
        }
    }

    UpdateEngergy () {
        var now = Date.now();
        var delta = now - this.energyTick;
        var amount = Math.floor(delta / ENERY_RECOVERY_TIME);

        this.energy += amount;
        if (this.energy > MAX_ENERGY) {
            this.energy = MAX_ENERGY;
        }

        this.energyTick += amount * ENERY_RECOVERY_TIME;
    }

    HasEnergy (amount) {
        return this.energy >= amount;
    }

    UseEnergy (amount) {
        this.energy -= amount;
    }

    Export () {
        return {
            energy: this.energy,
            energyTick: this.energyTick
        }
    }
}

module.exports = Player;
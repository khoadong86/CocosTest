const { unenumerable } = require('../../utils/ObjectHelper');

class Mill {
    constructor (data={}) {
        this.level = data.level || 1;
    }

    Export () {
        return {
            level: this.level
        }
    }
}

module.exports = Mill;
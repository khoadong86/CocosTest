const { unenumerable } = require('../../utils/ObjectHelper');

class Task {
    constructor (id, playerId, action, building, slot, duration, start_date) {
        console.log('New Task', id, playerId, action, building, slot, duration, start_date);
        this.id = id;
        this.player = playerId;
        this.action = action;
        this.building = building;
        this.slot = slot;
        this.duration = duration;
        this.start_date = start_date || Date.now();
        console.log('task created' + this.id + ' ' + this.start_date);
    }

    SpeedUp (amount) {
        this.duration -= amount;
        if (this.duration < 0)
            this.duration = 0;
    }

    IsCompleted () {
        console.log('task end: ' + (this.start_date + this.duration*1000) + " now " + Date.now());
        return this.duration == 0
            || (this.start_date + this.duration*1000) < Date.now();
    }

    Export () {
        var save = {
            id: this.id,
            player: this.player,
            action: this.action,
            building: this. building,
            duration: this.duration,
            start_date: this.start_date
        }

        if (this.slot !== null && this.slot !== undefined) {
            save.slot = this.slot;
        }

        return save;
    }
}

module.exports = Task;
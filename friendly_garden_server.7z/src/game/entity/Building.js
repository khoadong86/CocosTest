module.exports = {
    Farm_HQ: require('./SB_FarmHQ'),
    Farm_Storage_Barn: require('./SB_Barn'),
    PB_Soil_Plot: require('./PB_Soil'),
    PB_Mill: require('./PB_Mill'),
    PB_Bread_Oven: require('./PB_Oven'),
};
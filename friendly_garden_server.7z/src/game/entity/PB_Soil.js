const { unenumerable } = require('../../utils/ObjectHelper');

class Soil {
    constructor (data={}) {
        this.size = data.size || 3;
    }
    
    Export () {
        return {
            size: this.size
        }
    }
}

module.exports = Soil;
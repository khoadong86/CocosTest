const express = require('express');
const WebSocket = require('uws');
const { createServer } = require ('http');
const { Server } = require('colyseus');
const { monitor } = require('@colyseus/monitor');
const contextRoomPlugin = require('./src/plugins/ContextRoom');

const Game = require('./src/Game');
const GameDBHelper = require('./src/GameDBHelper');
// import global from './src/global';

const port = Number(process.env.PORT || 2567);

const boot = async function () {
    console.log("Try conenct to database");
    try {
        var connect = await GameDBHelper.Connect();
    } catch (e) {
        console.log(e);
        process.exit();
    }
    console.log("connected to database");
    
    const app = express();
    // Attach WebSocket Server on HTTP Server.
    const gameServer = new Server({
        engine: WebSocket.Server,
        server: createServer(app)
    });
    contextRoomPlugin(gameServer);
    
    gameServer.register("game", Game);
    
    // (optional) attach web monitoring panel
    app.use('/colyseus', monitor(gameServer));
    
    app.use('/', (req, res) => {
        console.log('Access homepage');
        return res.status(200).send('Welcome');
    })
    
    gameServer.onShutdown(function(){
        console.log(`game server is going down.`);
    });
    
    gameServer.listen(port);
    console.log(`Listening on http://localhost:${ port }`);
}

boot();